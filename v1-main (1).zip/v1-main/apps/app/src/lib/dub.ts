import { Dub } from "dub";

export const dub = new Dub();
