export function PostsLoading() {
  return <div>Loading...</div>;
}
