export default {
  welcome: "Bonjour {name}!",
} as const;
