export default {
  welcome: "Hello {name}!",
} as const;
