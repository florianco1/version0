"use server";

import { tasks } from "@trigger.dev/sdk/v3";
import type { helloWorldTask } from "@v1/jobs/trigger/example";

export async function myTask() {
  try {
    const handle = await tasks.trigger<typeof helloWorldTask>(
      "hello-world",
      "James",
    );

    return { handle };
  } catch (error) {
    console.error(error);
    return {
      error: "something went wrong",
    };
  }
}
