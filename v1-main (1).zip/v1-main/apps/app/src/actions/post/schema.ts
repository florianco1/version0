import { z } from "zod";

export const shareLinkSchema = z.object({
  postId: z.string(),
  baseUrl: z.string(),
});
